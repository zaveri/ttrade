class Gender < ActiveRecord::Base
  has_many :shirts
end
