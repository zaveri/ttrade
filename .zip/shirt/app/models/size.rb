class Size < ActiveRecord::Base
  has_many :shirts
end
