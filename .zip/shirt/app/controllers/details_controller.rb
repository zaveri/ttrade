class DetailsController < ApplicationController
  def index
  end

end
